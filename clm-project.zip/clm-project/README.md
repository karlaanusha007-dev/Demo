# Enterprise CLM — Salesforce DX Project

Opportunity & Contract Lifecycle Management system. This is being built incrementally,
layer by layer, so every commit is deployable on its own.

## Current status: Foundation + Apex core + Tabs

### Schema (done)
8 custom objects with all fields, relationships, and formulas:
- `Contract_Milestone__c` — master-detail to Contract
- `Contract_Document__c` — master-detail to Contract
- `Contract_Amendment__c` — master-detail to Contract, lookup to Clause_Library__c
- `Legal_Review__c` — master-detail to Contract, lookup to User
- `Risk_Assessment__c` — master-detail to Contract
- `Approval_History__c` — master-detail to Contract
- `Renewal__c` — lookup to Contract, Opportunity, Account, User
- `Clause_Library__c` — standalone reference object

### Apex core (done)
Opportunity → Contract lifecycle automation, following Trigger → Handler → Service →
Selector, fully bulkified (no SOQL/DML in loops):

- **Trigger / Handler**: `OpportunityTrigger` → `OpportunityTriggerHandler` →
  `TriggerHandlerBase` (shared base class used by all future triggers)
- **Services**: `OpportunityService` (detects Closed Won transitions),
  `ContractService` (creates Contract + all child records), `MilestoneService`
  (default milestone template), `RiskService` (baseline risk + overdue-penalty
  recalculation), `RenewalService` (renewal placeholder + renewal Opportunity
  generation), `ApprovalService` (submits to Approval Process, fails soft if none
  configured yet), `NotificationService` (email notifications, fails soft in
  sandboxes with deliverability disabled)
- **Selectors**: `OpportunitySelector`, `ContractSelector`, `MilestoneSelector`,
  `RenewalSelector`, `RiskAssessmentSelector` — all SOQL lives here, nowhere else
- **Tests**: `OpportunityContractFlowTest` (end-to-end + bulk 50-record + duplicate
  + non-won edge cases), `RiskServiceTest`, `RenewalServiceTest`

What's intentionally not yet wired up: there is no Approval Process metadata yet, so
`ApprovalService.submitContractsForApproval` will log a warning and continue rather
than throwing. This is by design — Contract creation must never be blocked by a
missing/misconfigured approval flow. The Approval Process itself comes in the
automation layer.

### Tabs (done)
One `CustomTab` per custom object, so all 8 are visible in App Manager once the
Lightning App is built. `motif` was deliberately left unset — Salesforce assigns
a sensible default and Lightning Experience nav uses the object's Object Manager
icon, not the classic tab motif, so this avoids guessing at icon/color codes that
could fail deployment.

### UI layer (done, kept intentionally simple)

Per request, this layer is minimal rather than the full 7-component spec:

- **`milestoneTracker` LWC** — a single, simple component showing a Contract's
  milestones (type, status, due date) in a plain SLDS table. Backed by
  `MilestoneTrackerController.getMilestonesForContract`, which delegates to the
  existing `MilestoneSelector` (no new SOQL introduced). Covered by
  `MilestoneTrackerControllerTest`.
- **`Contract_Record_Page` Flexipage** — standard Contract record page (header,
  detail tab, related lists tab) with `milestoneTracker` dropped into the sidebar.
  Built from a verified real-world structure (cross-checked against Salesforce's
  own `dreamhouse-lwc` sample app) rather than guessed, since Flexipage XML is
  unusually easy to get subtly wrong.
- **`Enterprise CLM` Lightning App** — simple custom app: Home, Opportunity,
  Account, and Contract standard tabs, plus all 8 custom object tabs. No console
  mode, no branding/logo, no utility bar — just navigation.

### Triggers (done) — Contract, Milestone, Renewal
Rounds out the trigger layer beyond Opportunity, same Trigger → Handler → Service
pattern throughout:

- **`ContractTrigger`** (`after update`) → `ContractTriggerHandler` detects Status
  field transitions and delegates to `ContractService.notifyOwnersOfStatusChange`.
- **`MilestoneTrigger`** (`after update`) → `MilestoneTriggerHandler` detects
  `Status__c` changes and calls `RiskService.recalculateRiskForOverdueMilestones`
  (this wires up risk scoring that previously only had test coverage via direct
  service calls, not via the trigger).
- **`RenewalTrigger`** (`before insert`) → `RenewalTriggerHandler` defaults missing
  fields (`Renewal_Status__c`, `Days_Before_Expiration__c`, `Renewal_Trigger_Date__c`,
  `Notification_Sent__c`) for Renewal records created outside the normal
  `RenewalService.scheduleRenewalsForContracts` path — e.g. manual creation or
  data load. Verified as a true no-op for records that already went through
  the service (every field is already set, so the `if (field == null)` guards
  never fire).

All three have dedicated test classes (`ContractTriggerHandlerTest`,
`MilestoneTriggerHandlerTest`, `RenewalTriggerHandlerTest`) covering the changed-field
detection logic, bulk updates, and default-preservation behavior.

### Contract Execution Flow (done)
Record-triggered Flow on `Contract_Milestone__c`: when a milestone of type
"Contract Closeout" transitions into Status = Completed, activates the related
Contract (`Status = Activated`). This is the piece `MilestoneService`'s own code
comment flagged as belonging in Flow, not Apex — milestone-driven Contract status
transitions are the declarative automation layer per the original architecture.

Built as Get Records → Update Records (not the relationship-shortcut pattern),
specifically because that two-step pattern's field names could be verified against
a real, published flow-analysis tool's example XML; the alternative shortcut
couldn't be confirmed from any verifiable source, so it was deliberately not used.
Uses `$Record__Prior` in the entry filter formula so it only fires on the actual
transition into Completed, not on every subsequent save of an already-completed
closeout milestone.

### Contract Approval Process (done)
Single-step approval process on Contract: routes to the **Contract Owner's
manager** via the standard manager hierarchy field (`nextAutomatedApprover` with
`useApproverFieldOfRecordOwner = true` and `userHierarchyField = "Manager"` — this
is the documented Salesforce mechanism for "owner's manager" as opposed to
"submitter's manager"). This gives `ApprovalService.submitContractsForApproval`
(built earlier, previously failing soft because no process existed) something
real to submit to. Kept intentionally simple per request: no email alerts or
field-update actions wired in, since those require additional `Workflow` metadata
that wasn't essential to demonstrate the approval routing itself.

### Not yet built
More LWCs, additional Record Pages beyond Contract, permission sets,
reports/dashboards, Batch/Queueable/Schedulable classes for the renewal pipeline.
These can be added in later passes if needed.

## How to deploy this slice to a scratch org or sandbox

Requires Salesforce CLI (`sf` or `sfdx`) installed and authenticated to an org.

```bash
# Authenticate to your org (if not already)
sf org login web --alias myOrg

# Deploy everything described in the manifest (objects, Apex, tabs)
sf project deploy start --manifest manifest/package.xml --target-org myOrg

# Or deploy everything in force-app
sf project deploy start --source-dir force-app --target-org myOrg

# Run just this project's Apex tests after deploying
sf apex run test --class-names OpportunityContractFlowTest,RiskServiceTest,RenewalServiceTest,MilestoneTrackerControllerTest,MilestoneTriggerHandlerTest,ContractTriggerHandlerTest,RenewalTriggerHandlerTest --target-org myOrg --result-format human
```

## Project structure

```
force-app/main/default/
  objects/             <- 8 custom objects + fields (done)
  classes/             <- Apex: handlers, services, selectors, controller, tests (done)
  triggers/             <- Opportunity, Contract, Milestone, Renewal (done)
  tabs/                <- CustomTab per custom object (done)
  lwc/                 <- milestoneTracker (done; more later if needed)
  flexipages/          <- Contract_Record_Page (done; more later if needed)
  applications/        <- Enterprise_CLM (done)
  flows/               <- Contract_Execution_Flow (done)
  approvalProcesses/   <- Contract.Contract_Approval (done)
  permissionsets/      <- Security model (later layer)
  ...
```

## Notes

- All custom objects use `ControlledByParent` sharing (inherited from Contract) except
  `Renewal__c` (Private — it's lookup-based, not master-detail) and `Clause_Library__c`
  (Read — it's an org-wide reference table).
- Formula fields (`Days_Overdue__c`, `Is_Overdue__c`, `Risk_Level__c`) use standard
  Salesforce formula syntax — verified for valid syntax (e.g. nested `IF()` instead of
  `CASE(TRUE,...)`, which Salesforce does not support).
- The full Opportunity→Contract chain issues exactly 7 DML statements regardless of
  batch size (1 record or 200) — verified by code inspection, see DML statement list
  in `ContractService`, `MilestoneService`, `RiskService`, `RenewalService`.
- `ContractService.createContractsForWonOpportunities` guarantees its returned list
  is the same order/length as the input list — `OpportunityService` relies on this
  for index-based pairing with Opportunity owner Ids. Documented inline; don't break it.

