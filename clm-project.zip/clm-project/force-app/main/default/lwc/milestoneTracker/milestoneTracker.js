import { LightningElement, api, wire } from 'lwc';
import getMilestonesForContract from '@salesforce/apex/MilestoneTrackerController.getMilestonesForContract';

export default class MilestoneTracker extends LightningElement {
    @api recordId; // Contract Id, automatically provided when placed on a Contract record page

    isLoading = true;
    hasError = false;
    rawMilestones = [];

    @wire(getMilestonesForContract, { contractId: '$recordId' })
    wiredMilestones({ data, error }) {
        this.isLoading = false;
        if (data) {
            this.rawMilestones = data;
            this.hasError = false;
        } else if (error) {
            this.hasError = true;
            this.rawMilestones = [];
        }
    }

    get milestones() {
        return this.rawMilestones.map((m) => ({
            ...m,
            formattedDueDate: m.Due_Date__c
                ? new Date(m.Due_Date__c + 'T00:00:00').toLocaleDateString()
                : '—'
        }));
    }

    get hasMilestones() {
        return !this.isLoading && !this.hasError && this.rawMilestones.length > 0;
    }

    get hasNoMilestones() {
        return !this.isLoading && !this.hasError && this.rawMilestones.length === 0;
    }
}
