/**
 * Thin trigger for the standard Contract object. All logic lives in
 * ContractTriggerHandler.
 */
trigger ContractTrigger on Contract (after update) {
    new ContractTriggerHandler().run();
}
