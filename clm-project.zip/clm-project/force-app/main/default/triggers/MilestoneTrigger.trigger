/**
 * Thin trigger for Contract_Milestone__c. All logic lives in
 * MilestoneTriggerHandler.
 */
trigger MilestoneTrigger on Contract_Milestone__c (after update) {
    new MilestoneTriggerHandler().run();
}
