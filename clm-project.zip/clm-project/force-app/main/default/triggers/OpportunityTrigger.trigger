/**
 * Thin trigger for Opportunity. All logic lives in OpportunityTriggerHandler.
 * Registered for the contexts the handler actually implements (after
 * insert/update) to avoid wasted invocation overhead on unused contexts.
 */
trigger OpportunityTrigger on Opportunity (after insert, after update) {
    new OpportunityTriggerHandler().run();
}
