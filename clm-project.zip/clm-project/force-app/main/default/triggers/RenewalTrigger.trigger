/**
 * Thin trigger for Renewal__c. All logic lives in RenewalTriggerHandler.
 */
trigger RenewalTrigger on Renewal__c (before insert) {
    new RenewalTriggerHandler().run();
}
